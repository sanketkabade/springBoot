package delarRegistraction;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DelarRepo extends JpaRepository<DelarRegistraction, Integer> {

}
